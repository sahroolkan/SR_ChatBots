<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Botman Chatbot in Laravel - Real Programmer</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
</head>

<body>
</body>

<link rel="stylesheet" type="text/css"
    href="https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/assets/css/chat.min.css">
<script>
var botmanWidget = {
    aboutText: 'Silahkan tuliskan suatu',
    introMessage: "✋ Hi! Selamat datang di Sahrul Romadon ChatBot"
};
</script>

<script src='https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/js/widget.js'></script>

</html><?php /**PATH /home/sahrudin/Desktop/sr_chatBot/resources/views/welcome.blade.php ENDPATH**/ ?>